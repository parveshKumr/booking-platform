package com.booking.platform.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.booking.platform.entity.Movie;
import com.booking.platform.entity.ShowTime;
import com.booking.platform.entity.Theatre;
import com.booking.platform.model.ShowTimeModel;
import com.booking.platform.service.ShowTimeService;
import com.fasterxml.jackson.databind.ObjectMapper;

@ContextConfiguration(classes = {ShowTimeController.class})
@WebMvcTest(ShowTimeController.class)
class ShowTimeControllerTest {

	@MockBean
	private ShowTimeService showTimeService;
	
	@Autowired
	private MockMvc mockMvc;
	
	ShowTime showTime;
	List<ShowTime> showTimeList;
	List<ShowTimeModel> showTimeModelList;
	
	@BeforeEach
	public void createShowTime() {
		Movie movie = new Movie();
		movie.setDirector("ABC");
		movie.setTitle("Dummy");
		
		Theatre theatre = new Theatre();
		theatre.setCity("City");
		theatre.setEmail("info@theatre.com");
		theatre.setName("name");
		
		showTime = ShowTime.builder().movie(movie).theatre(theatre).startDate(LocalDate.now()).endDate(LocalDate.now()).build();
		ShowTime showTime1 = ShowTime.builder().movie(movie).theatre(theatre).startDate(LocalDate.now()).endDate(LocalDate.now()).build();
		
		showTimeList = new ArrayList<>();
		showTimeList.add(showTime);
		showTimeList.add(showTime1);
		
		ShowTimeModel showTimeModel = new ShowTimeModel();
		showTimeModel.setMovieId(1L);
		showTimeModel.setTheatreId(1L);
		showTimeModel.setShowDate("2024-05-30");

		ShowTimeModel showTimeModel1 = new ShowTimeModel();
		showTimeModel1.setMovieId(1L);
		showTimeModel1.setTheatreId(2L);
		showTimeModel1.setShowDate("2024-05-30");
		showTimeModelList = new ArrayList<>();
		showTimeModelList.add(showTimeModel1);
		showTimeModelList.add(showTimeModel);
	}
	
	@Test
	void test_createShowTime() throws Exception {
		when(showTimeService.createUpdateShowTime(anyList())).thenReturn(showTimeList);
		String content = (new ObjectMapper()).writeValueAsString(showTimeModelList);
		ResultActions response = mockMvc.perform(
				post("/api/v1/show-time").contentType(MediaType.APPLICATION_JSON).content(content));
		response.andExpect(status().isOk());
	}

	@Test
	void test_updateShowTime() throws Exception {
		when(showTimeService.createUpdateShowTime(anyList())).thenReturn(showTimeList);
		String content = (new ObjectMapper()).writeValueAsString(showTimeModelList);
		ResultActions response = mockMvc.perform(
				put("/api/v1/show-time").contentType(MediaType.APPLICATION_JSON).content(content));
		response.andExpect(status().isOk());
	}
	
	@Test
	void test_deleteShowTime() throws Exception {
		doNothing().when(showTimeService).deleteShowTime(any());
		when(showTimeService.createUpdateShowTime(anyList())).thenReturn(showTimeList);
		ResultActions response = mockMvc.perform(
				delete("/api/v1/show-time/{id}", 1L));
		response.andExpect(status().isOk());
	}
}
