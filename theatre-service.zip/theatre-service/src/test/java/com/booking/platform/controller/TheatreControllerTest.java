package com.booking.platform.controller;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.booking.platform.entity.Theatre;
import com.booking.platform.service.TheatreService;

@ContextConfiguration(classes = {TheatreController.class})
@WebMvcTest(TheatreController.class)
class TheatreControllerTest {
	
	@MockBean
	private TheatreService theatreService;
	
	@Autowired
	private MockMvc mockMvc;

	List<Theatre> theatreList;
	
	@BeforeEach
	public void createTheatres() {
		Theatre th = new Theatre();
		th.setCity("city");
		th.setEmail("info@th.com");
		th.setName("th");
		th.setPhone("1516131653");
		
		theatreList = new ArrayList<>();
		theatreList.add(th);
	}

	@Test
	void test_findTheatres() throws Exception {
		when(theatreService.getTheatersBasedOnMovieCityAndDate(anyLong(), anyString(), anyString())).thenReturn(theatreList);
		ResultActions response = mockMvc.perform(
				get("/api/v1/theatre/movie/{movieId}/city/{city}/date/{showDate}", 1L, "AnyTown", "2024-05-30"));
		response.andExpect(status().isOk());
	}
}
