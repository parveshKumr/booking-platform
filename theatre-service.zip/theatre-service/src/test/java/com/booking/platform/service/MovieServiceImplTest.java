package com.booking.platform.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import com.booking.platform.entity.Movie;
import com.booking.platform.exception.MovieNotFoundException;
import com.booking.platform.repository.MovieRepository;
import com.booking.platform.service.impl.MovieServiceImpl;

@ContextConfiguration(classes = {MovieServiceImpl.class})
@WebMvcTest(MovieServiceImpl.class)
class MovieServiceImplTest {

	@MockBean
	private MovieRepository movieRepository;
	
	@Autowired
	private MovieService movieService;
	
	Movie movie;
	
	@BeforeEach
	public void createMovie() {
		movie = new Movie();
		movie.setDirector("dir");
		movie.setTitle("title");
		movie.setId(15L);
	}

	
	@Test
	void test_findMovieByIdNotFound() throws Exception {
		when(movieRepository.findById(any())).thenReturn(Optional.empty());
		assertThrows(MovieNotFoundException.class, () -> movieService.findMovieById(1L));
		verify(movieRepository, times(1)).findById(any());
	}
	
	@Test
	void test_findMovieById() throws Exception {
		when(movieRepository.findById(any())).thenReturn(Optional.of(movie));
		Movie movie = movieService.findMovieById(15L);
		assertNotNull(movie);
		assertEquals(15L, movie.getId());
		verify(movieRepository, times(1)).findById(any());
	}
}
