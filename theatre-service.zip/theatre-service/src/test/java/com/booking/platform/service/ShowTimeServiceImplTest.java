package com.booking.platform.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import com.booking.platform.entity.Movie;
import com.booking.platform.entity.ShowTime;
import com.booking.platform.entity.Theatre;
import com.booking.platform.exception.ShowTimeNotFoundException;
import com.booking.platform.model.ShowTimeModel;
import com.booking.platform.repository.ShowTimeRepository;
import com.booking.platform.service.impl.ShowTimeServiceImpl;

@ContextConfiguration(classes = {ShowTimeServiceImpl.class})
@WebMvcTest(ShowTimeServiceImpl.class)
class ShowTimeServiceImplTest {

	@MockBean
	private ShowTimeRepository showTimeRepository;
	
	@Autowired
	private ShowTimeService showTimeService;
	
	@MockBean
	private MovieService movieService;
	
	@MockBean
	private TheatreService theatreService;
	
	
	ShowTime showTime;
	List<ShowTime> showTimeList;
	
	List<ShowTimeModel> modelList;
	
	@BeforeEach
	public void createShowTime() {
		showTime = new ShowTime();
		showTime.setId(12L);
		showTime.setMovie(new Movie());
		showTime.setTheatre(new Theatre());
		
		showTimeList = new ArrayList<>();
		showTimeList.add(showTime);
		
		ShowTimeModel model = new ShowTimeModel();
		model.setMovieId(1L);
		model.setShowDate("2024-05-30");
		model.setShowTimeId(12L);
		model.setTheatreId(2L);
		
		modelList = new ArrayList<>();
		modelList.add(model);
	}

	@Test
	void test_createUpdateShowTime() throws Exception {
		when(movieService.findMovieById(any())).thenReturn(new Movie());
		when(theatreService.findTheatreById(any())).thenReturn(new Theatre());
		when(showTimeRepository.saveAll(anyList())).thenReturn(showTimeList);
		List<ShowTime> list = showTimeService.createUpdateShowTime(modelList);
		assertNotNull(list);
		assertEquals(1, list.size());
		assertEquals(12, list.get(0).getId());
	}
	
	@Test
	void test_deleteShowTimeNotFound() throws Exception {
		when(showTimeRepository.findById(any())).thenReturn(Optional.empty());
		doNothing().when(showTimeRepository).delete(any());
		assertThrows(ShowTimeNotFoundException.class, () -> showTimeService.deleteShowTime(1L));
		verify(showTimeRepository, times(1)).findById(any());
	}
	
	@Test
	void test_deleteShowTime() throws Exception {
		when(showTimeRepository.findById(any())).thenReturn(Optional.of(showTime));
		doNothing().when(showTimeRepository).delete(any());
		showTimeService.deleteShowTime(15L);
		verify(showTimeRepository, times(1)).findById(any());
		verify(showTimeRepository, times(1)).delete(any());
	}
}
