package com.booking.platform.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import com.booking.platform.entity.Theatre;
import com.booking.platform.exception.TheatreNotFoundException;
import com.booking.platform.repository.TheatreRepository;
import com.booking.platform.service.impl.TheatreServiceImpl;

@ContextConfiguration(classes = {TheatreServiceImpl.class})
@WebMvcTest(TheatreServiceImpl.class)
class TheatreServiceImplTest {

	@MockBean
	private TheatreRepository theatreRepository;
	
	@Autowired
	private TheatreService theatreService;
	
	List<Theatre> theatreList;
	Theatre th;
	
	@BeforeEach
	public void createTheatres() {
		th = new Theatre();
		th.setCity("city");
		th.setEmail("info@th.com");
		th.setName("th");
		th.setPhone("1516131653");
		th.setId(15L);
		theatreList = new ArrayList<>();
		theatreList.add(th);
	}

	
	@Test
	void test_getTheatersBasedOnMovieCityAndDate() throws Exception {
		when(theatreRepository.findTheatreByMovieCityAndDate(anyLong(), any(), any())).thenReturn(theatreList);
		List<Theatre> th = theatreService.getTheatersBasedOnMovieCityAndDate(1L, "city", "2024-05-30");
		assertNotNull(th);
		assertEquals(1, th.size());
		assertEquals(15L, th.get(0).getId());
	}
	
	@Test
	void test_getTheatersBasedOnMovieCityAndDateNotFoundException() throws Exception {
		when(theatreRepository.findTheatreByMovieCityAndDate(anyLong(), any(), any())).thenReturn(Collections.EMPTY_LIST);
		assertThrows(TheatreNotFoundException.class, () -> theatreService.getTheatersBasedOnMovieCityAndDate(1L, "city", "2024-05-30"));
		verify(theatreRepository, times(1)).findTheatreByMovieCityAndDate(anyLong(), any(), any());
	}
	
	@Test
	void test_findTheatreByIdNotFound() throws Exception {
		when(theatreRepository.findById(any())).thenReturn(Optional.empty());
		assertThrows(TheatreNotFoundException.class, () -> theatreService.findTheatreById(1L));
		verify(theatreRepository, times(1)).findById(any());
	}
	
	@Test
	void test_findTheatreById() throws Exception {
		when(theatreRepository.findById(any())).thenReturn(Optional.of(th));
		Theatre theatre = theatreService.findTheatreById(15L);
		assertNotNull(theatre);
		assertEquals(15L, theatre.getId());
		verify(theatreRepository, times(1)).findById(any());
	}
}
