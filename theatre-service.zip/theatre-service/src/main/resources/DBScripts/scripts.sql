-------------------------- BOOKING SERVICE -----------------------------
CREATE TABLE IF NOT EXISTS booking.booking
(
    booking_status smallint NOT NULL,
    payment_method smallint,
    total_price numeric(38,2) NOT NULL,
    booking_date_time timestamp(6) without time zone NOT NULL,
    booking_id bigint NOT NULL DEFAULT nextval('booking_booking_id_seq'::regclass),
    discount_id bigint,
    movie_id bigint NOT NULL,
    show_time_id bigint NOT NULL,
    user_id bigint NOT NULL,
    booking_reference_number character varying(255) COLLATE pg_catalog."default" NOT NULL,
    booking_source character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT booking_pkey PRIMARY KEY (booking_id),
    CONSTRAINT booking_booking_reference_number_key UNIQUE (booking_reference_number),
    CONSTRAINT booking_booking_status_check CHECK (booking_status >= 0 AND booking_status <= 3),
    CONSTRAINT booking_payment_method_check CHECK (payment_method >= 0 AND payment_method <= 2)
);

-------------------------- DISCOUNT SERVICE ---------------------------------
CREATE TABLE IF NOT EXISTS discount.credit_card_discounts
(
    discount_percentage numeric(38,2) NOT NULL,
    credit_card_discount_id bigint NOT NULL DEFAULT nextval('credit_card_discounts_credit_card_discount_id_seq'::regclass),
    discount_id bigint NOT NULL,
    credit_card_type character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT credit_card_discounts_pkey PRIMARY KEY (credit_card_discount_id),
    CONSTRAINT credit_card_discounts_discount_id_key UNIQUE (discount_id),
    CONSTRAINT fkn7xcsdk81waa0ul39w6b13bnt FOREIGN KEY (discount_id)
        REFERENCES public.discounts (discount_id) MATCH SIMPLE
);

CREATE TABLE IF NOT EXISTS discount.discounts
(
    discount_id bigint NOT NULL DEFAULT nextval('discounts_discount_id_seq'::regclass),
    theatre_id bigint,
    city character varying(255) COLLATE pg_catalog."default",
    name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    type character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT discounts_pkey PRIMARY KEY (discount_id)
);

CREATE TABLE IF NOT EXISTS discount.show_slot_discounts
(
    discount_percentage numeric(38,2) NOT NULL,
    discount_id bigint NOT NULL,
    show_slot_discount_id bigint NOT NULL DEFAULT nextval('show_slot_discounts_show_slot_discount_id_seq'::regclass),
    show_time_id bigint,
    CONSTRAINT show_slot_discounts_pkey PRIMARY KEY (show_slot_discount_id),
    CONSTRAINT show_slot_discounts_discount_id_key UNIQUE (discount_id),
    CONSTRAINT fkrvvaqdmqa4lumrhx8slr5pax3 FOREIGN KEY (discount_id)
        REFERENCES public.discounts (discount_id) MATCH SIMPLE
);


------------------- User Service --------------------------------
CREATE TABLE IF NOT EXISTS user.favorite_movies
(
    id bigint NOT NULL DEFAULT nextval('favorite_movies_id_seq'::regclass),
    user_id bigint NOT NULL,
    movie_title character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT favorite_movies_pkey PRIMARY KEY (id),
    CONSTRAINT fkpcy84p84pv7y5p8qmkwdry84b FOREIGN KEY (user_id)
        REFERENCES public.users (user_id) MATCH SIMPLE
);

CREATE TABLE IF NOT EXISTS public.users
(
    user_id bigint NOT NULL DEFAULT nextval('users_user_id_seq'::regclass),
    email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    location character varying(255) COLLATE pg_catalog."default",
    password character varying(255) COLLATE pg_catalog."default" NOT NULL,
    username character varying(255) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT users_pkey PRIMARY KEY (user_id),
    CONSTRAINT users_email_key UNIQUE (email),
    CONSTRAINT users_username_key UNIQUE (username)
);

CREATE TABLE IF NOT EXISTS public.watch_list_movies
(
    id bigint NOT NULL DEFAULT nextval('watch_list_movies_id_seq'::regclass),
    movie_id bigint NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT watch_list_movies_pkey PRIMARY KEY (id),
    CONSTRAINT fkj0pu47awl7tl2uoiee82k8f85 FOREIGN KEY (user_id)
        REFERENCES public.users (user_id) MATCH SIMPLE
)
--------------------------------- THEATRE SERVICE -------------------------------------

CREATE TABLE IF NOT EXISTS public.movie
(
    duration integer,
    movie_id bigint NOT NULL DEFAULT nextval('movie_movie_id_seq'::regclass),
    director character varying(255) COLLATE pg_catalog."default",
    title character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT movie_pkey PRIMARY KEY (movie_id)
);

CREATE TABLE IF NOT EXISTS public.seats
(
    col_number integer NOT NULL,
    is_available boolean NOT NULL,
    row_number integer NOT NULL,
    seat_id bigint NOT NULL DEFAULT nextval('seats_seat_id_seq'::regclass),
    show_time_id bigint NOT NULL,
    CONSTRAINT seats_pkey PRIMARY KEY (seat_id),
    CONSTRAINT fkmwc1m3dtrq4kbnbwxhi2krnrd FOREIGN KEY (show_time_id)
        REFERENCES public.show_time (id) MATCH SIMPLE
);

CREATE TABLE IF NOT EXISTS public.show_slot_seats
(
    is_available boolean NOT NULL,
    id bigint NOT NULL DEFAULT nextval('show_slot_seats_id_seq'::regclass),
    seat_id bigint NOT NULL,
    show_slots_id bigint NOT NULL,
    CONSTRAINT show_slot_seats_pkey PRIMARY KEY (id),
    CONSTRAINT fk4r8lxdouhf41d5nmx4epwicl2 FOREIGN KEY (show_slots_id)
        REFERENCES public.show_slots (show_slots_id) MATCH SIMPLE,
    CONSTRAINT fkmssieq30hela812uioo3f3w0o FOREIGN KEY (seat_id)
        REFERENCES public.seats (seat_id) MATCH SIMPLE
);

CREATE TABLE IF NOT EXISTS public.show_slots
(
    price numeric(38,2),
    start_time time(6) without time zone,
    show_slots_id bigint NOT NULL DEFAULT nextval('show_slots_show_slots_id_seq'::regclass),
    CONSTRAINT show_slots_pkey PRIMARY KEY (show_slots_id)
);

CREATE TABLE IF NOT EXISTS public.show_time
(
    end_date date,
    start_date date,
    id bigint NOT NULL DEFAULT nextval('show_time_id_seq'::regclass),
    movie_id bigint NOT NULL,
    theatre_id bigint NOT NULL,
    CONSTRAINT show_time_pkey PRIMARY KEY (id),
    CONSTRAINT fk8e72rkmjwjag9nshwu5hvh6b4 FOREIGN KEY (movie_id)
        REFERENCES public.movie (movie_id) MATCH SIMPLE,
    CONSTRAINT fkincoa765dq6fh4sdn1iagknhy FOREIGN KEY (theatre_id)
        REFERENCES public.theatre (theatre_id) MATCH SIMPLE
);

CREATE TABLE IF NOT EXISTS public.theatre
(
    theatre_id bigint NOT NULL DEFAULT nextval('theatre_theatre_id_seq'::regclass),
    city character varying(255) COLLATE pg_catalog."default",
    email character varying(255) COLLATE pg_catalog."default",
    name character varying(255) COLLATE pg_catalog."default",
    phone character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT theatre_pkey PRIMARY KEY (theatre_id)
);


--------------------------------------- PAYMENT SERVICE ------------------------------------

CREATE TABLE IF NOT EXISTS payment.payments
(
    amount numeric(38,2) NOT NULL,
    payment_method smallint NOT NULL,
    payment_status smallint NOT NULL,
    payment_date_time timestamp(6) without time zone NOT NULL,
    payment_id bigint NOT NULL DEFAULT nextval('payments_payment_id_seq'::regclass),
    user_id bigint NOT NULL,
    CONSTRAINT payments_pkey PRIMARY KEY (payment_id),
    CONSTRAINT payments_payment_method_check CHECK (payment_method >= 0 AND payment_method <= 2),
    CONSTRAINT payments_payment_status_check CHECK (payment_status >= 0 AND payment_status <= 2)
);

