package com.booking.platform.exception;

public class TheatreNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TheatreNotFoundException(String erroMessage) {
		super(erroMessage);
	}
}
