package com.booking.platform.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "show_slot_seats")
public class ShowSlotSeats {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@ManyToOne
	@JoinColumn(name = "show_slots_id", nullable = false)
	private ShowSlots showSlots;

	@ManyToOne
	@JoinColumn(name = "seat_id", nullable = false)
	private Seats seat;

	@Column(name = "is_available", nullable = false)
	private boolean isAvailable;

}
