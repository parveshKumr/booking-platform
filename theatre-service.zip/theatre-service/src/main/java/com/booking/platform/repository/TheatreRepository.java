package com.booking.platform.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.booking.platform.entity.Theatre;

@Repository
public interface TheatreRepository extends JpaRepository<Theatre, Long> {

	@Query("SELECT DISTINCT s.theatre FROM ShowTime s WHERE s.movie.id = :movie "
			+ "AND s.theatre.city = :city AND s.startDate <= :showDate "
			+ "AND s.endDate >= :showDate")
	List<Theatre> findTheatreByMovieCityAndDate(@Param("movie") Long movieId, @Param("city") String city, @Param("showDate") LocalDate showDate);

}
