package com.booking.platform.model;

import org.springframework.validation.annotation.Validated;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Validated
public class ShowTimeModel {

	private Long showTimeId;
	@NotNull(message = "Movie details is mandatory for the show")
	private Long movieId;
	
	@NotNull(message = "Theatre details is mandatory for the show")
	private Long theatreId;
	
	@NotNull(message = "Show date is mandatory for the show")
	private String showDate;
	
//	@NotNull(message = "Show slot is mandatory for the show")
//	private Long showSlotId;
}
