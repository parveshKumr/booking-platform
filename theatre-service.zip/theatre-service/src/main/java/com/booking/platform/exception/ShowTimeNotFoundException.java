package com.booking.platform.exception;

public class ShowTimeNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShowTimeNotFoundException(String erroMessage) {
		super(erroMessage);
	}
}
