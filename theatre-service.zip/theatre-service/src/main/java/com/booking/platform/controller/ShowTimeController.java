package com.booking.platform.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.platform.entity.ShowTime;
import com.booking.platform.model.ShowTimeModel;
import com.booking.platform.service.ShowTimeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/show-time")
@Slf4j
@Validated
@RequiredArgsConstructor
public class ShowTimeController {

	private final ShowTimeService showTimeService;
	
	@Operation(summary = "Create show time", description = "Create showtime")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "404", description = "Theatre/Movie Not Found"),
            @ApiResponse(responseCode = "400", description = "Bad Request") })
    @PostMapping
	public List<ShowTime> createShowTime(@Valid @RequestBody List<ShowTimeModel> model){
		log.info("Create show time");
		return showTimeService.createUpdateShowTime(model);
	}
	
	@Operation(summary = "Update show time", description = "Update showtime")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "404", description = "Theatre/Movie Not Found"),
            @ApiResponse(responseCode = "400", description = "Bad Request") })
    @PutMapping
	public List<ShowTime> updateShowTime(@Valid @RequestBody List<ShowTimeModel> model){
		return showTimeService.createUpdateShowTime(model);
	}

	@Operation(summary = "Delete show time", description = "Delete showtime")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "404", description = "Show time Not Found"),
            @ApiResponse(responseCode = "400", description = "Bad Request") })
    @DeleteMapping("/{id}")
	public ResponseEntity<String> deleteShowTime(@PathVariable final Long id){
		showTimeService.deleteShowTime(id);
		return ResponseEntity.ok().build();
	}

}
