package com.booking.platform.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.booking.platform.exception.MovieNotFoundException;
import com.booking.platform.exception.ShowTimeNotFoundException;
import com.booking.platform.exception.TheatreNotFoundException;

import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class TheatreServiceAdvice {

	@ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception exc) {
        String message = "Error : Something went wrong, please try after sometime";
        log.error(message + " {}", exc.getMessage(), exc);
        return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(TheatreNotFoundException.class)
    public ResponseEntity<String> handleTheatreNotFoundException(TheatreNotFoundException exc) {
        String message = exc.getMessage();
        log.error("Error : {} ", message, exc);
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(ShowTimeNotFoundException.class)
    public ResponseEntity<String> handleShowTimeNotFoundException(ShowTimeNotFoundException exc) {
        String message = exc.getMessage();
        log.error("Error : {} ", message, exc);
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(MovieNotFoundException.class)
    public ResponseEntity<String> handleMovieNotFoundException(MovieNotFoundException exc) {
        String message = exc.getMessage();
        log.error("Error : {} ", message, exc);
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException exc){
		String message = exc.getMessage();
        log.error("Error : {} ", message, exc);
        return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
	}
}
