package com.booking.platform.entity;

import java.math.BigDecimal;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "show_slots")
public class ShowSlots {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "show_slots_id")
	private Long id;
	
	@Column(name = "start_time")
	private LocalTime startTime;
	
	@Column(name = "price")
	private BigDecimal price;
	
}
