package com.booking.platform.entity.delete;

public enum PaymentMethod {
	CREDIT_CARD, DEBIT_CARD, CASH
}
