package com.booking.platform.service;

import com.booking.platform.entity.Movie;

public interface MovieService {

	Movie findMovieById(final Long movieId);
}
