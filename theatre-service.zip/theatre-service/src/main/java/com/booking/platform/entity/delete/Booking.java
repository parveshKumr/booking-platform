package com.booking.platform.entity.delete;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "booking")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "movie_id", nullable = false)
    private Long movieId;

    @Column(name = "show_time_id", nullable = false)
    private Long showTimeId;

    @Column(name = "payment_method")
    @Enumerated
    private PaymentMethod paymentMethod;
    
    @Column(name = "discount_id")
    private Long discountId;
    
    @Column(name = "booking_status", nullable = false)
    @Enumerated
    private BookingStatus bookingStatus;

    @Column(name = "booking_date_time", nullable = false)
    private LocalDateTime bookingDateTime;

    @Column(name = "total_price", nullable = false)
    private BigDecimal totalPrice;

    @Column(name = "booking_reference_number", nullable = false, unique = true)
    private String bookingReferenceNumber;

    @Column(name = "booking_source")
    private String bookingSource;

}

