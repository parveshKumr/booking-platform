package com.booking.platform.entity.delete;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "payment_method", nullable = false)
    @Enumerated
    private PaymentMethod paymentMethod; // e.g., "credit_card", "debit_card", "cash", etc.

    @Column(name = "payment_status", nullable = false)
    @Enumerated
    private PaymentStatus paymentStatus; // e.g., "pending", "completed", "failed"

    @Column(name = "payment_date_time", nullable = false)
    private LocalDateTime paymentDateTime;

}

