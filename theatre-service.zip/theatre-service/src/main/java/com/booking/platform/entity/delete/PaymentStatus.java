package com.booking.platform.entity.delete;

public enum PaymentStatus {
	PENDING, COMPLETED, FAILED
}	
