package com.booking.platform.entity.delete;

public enum BookingStatus {

	CONFIRMED, PENDING, CANCELLED, FAILED
}
