package com.booking.platform.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.booking.platform.entity.Theatre;
import com.booking.platform.exception.TheatreNotFoundException;
import com.booking.platform.repository.TheatreRepository;
import com.booking.platform.service.TheatreService;
import com.booking.platform.utils.TheatreServiceUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class TheatreServiceImpl implements TheatreService{
	
	private final TheatreRepository theatreRepository;
	
	@Override
	public List<Theatre> getTheatersBasedOnMovieCityAndDate(final Long movieId, final String city, final String showDate) {
		log.info("Get Theatres based on criteria movie {}, city {}, date {}", movieId, city, showDate);
		final List<Theatre> theatres = theatreRepository.findTheatreByMovieCityAndDate(movieId, city, TheatreServiceUtil.convert(showDate));
		if(null == theatres || theatres.isEmpty()) {
			throw new TheatreNotFoundException("No Theatre Available");
		}
		return theatres;
	}

	@Override
	public Theatre findTheatreById(Long theatreId) {
		log.debug("Find Theatre by Id {}", theatreId);
		return theatreRepository.findById(theatreId)
				.orElseThrow(() -> new TheatreNotFoundException("Theatre Not found with id:" + theatreId));
	}

}
