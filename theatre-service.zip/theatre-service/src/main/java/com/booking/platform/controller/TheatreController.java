package com.booking.platform.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.platform.entity.Theatre;
import com.booking.platform.service.TheatreService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/theatre")
@Slf4j
@RequiredArgsConstructor
public class TheatreController {

	private final TheatreService theatreService;
	
	@Operation(summary = "Get Theatres based on Movie, City and show date", description = "get All theatres based on selected movie, city and date")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "404", description = "No Theatre Found"),
            @ApiResponse(responseCode = "400", description = "Bad Request") })
    @GetMapping("/movie/{movieId}/city/{city}/date/{showDate}")
	public List<Theatre> findTheatres(@PathVariable Long movieId,
			@PathVariable String city, @PathVariable String showDate){
		log.info("Get theatres based on movie, city and date");
		return theatreService.getTheatersBasedOnMovieCityAndDate(movieId, city, showDate);
	}
}
