package com.booking.platform.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.booking.platform.entity.Movie;
import com.booking.platform.exception.MovieNotFoundException;
import com.booking.platform.repository.MovieRepository;
import com.booking.platform.service.MovieService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
@Slf4j
public class MovieServiceImpl implements MovieService{

	
	private final MovieRepository movieRepository;
	
	@Override
	public Movie findMovieById(final Long movieId) {
		log.debug("Find Movie by Id {}", movieId);
		return movieRepository.findById(movieId)
				.orElseThrow(() -> new MovieNotFoundException("Movie Not Found with id:"+ movieId));
	}
}
