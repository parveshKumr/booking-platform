package com.booking.platform.entity.delete;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "credit_card_discounts")
public class CreditCardDiscount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "credit_card_discount_id")
    private Long id;

    @OneToOne
    @JoinColumn(name = "discount_id", nullable = false)
    private Discount discount;

    @Column(name = "credit_card_type", nullable = false)
    private String creditCardType;

    @Column(name = "discount_percentage", nullable = false)
    private BigDecimal discountPercentage;

}
