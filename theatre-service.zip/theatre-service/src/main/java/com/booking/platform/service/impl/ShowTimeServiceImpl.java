package com.booking.platform.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.booking.platform.entity.ShowTime;
import com.booking.platform.exception.ShowTimeNotFoundException;
import com.booking.platform.model.ShowTimeModel;
import com.booking.platform.repository.ShowTimeRepository;
import com.booking.platform.service.MovieService;
import com.booking.platform.service.ShowTimeService;
import com.booking.platform.service.TheatreService;
import com.booking.platform.utils.TheatreServiceUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ShowTimeServiceImpl implements ShowTimeService{

	private final ShowTimeRepository showTimeRepository;
	
	private final MovieService movieService;
	
	private final TheatreService theatreService;
	
	@Override
	@Transactional
	public List<ShowTime> createUpdateShowTime(final List<ShowTimeModel> model) {
		log.debug("Create/Update show time");
		return showTimeRepository.saveAll(model.stream().map(this::convertDtoToEntity).toList());
	}

	@Override
	@Transactional
	public void deleteShowTime(final Long id) {
		log.debug("Delete show time {}", id);
		final ShowTime showTime = showTimeRepository.findById(id)
				.orElseThrow(() -> new ShowTimeNotFoundException("Showtime not found with id:" + id));
		showTimeRepository.delete(showTime);
	}
	
	private ShowTime convertDtoToEntity(final ShowTimeModel model) {
		log.debug("Convert show time model to show time entity");
		final LocalDate showDate = TheatreServiceUtil.convert(model.getShowDate());
		return ShowTime.builder().id(model.getShowTimeId()).startDate(showDate).endDate(showDate)
				.movie(movieService.findMovieById(model.getMovieId()))
				.theatre(theatreService.findTheatreById(model.getTheatreId())).build();
	}
}
