package com.booking.platform.entity.delete;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "show_slot_discounts")
public class ShowSlotsDiscount {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "show_slot_discount_id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "discount_id", nullable = false)
	private Discount discount;

	@Column(name = "show_time_id")
	private Long showTimeId;
	
	@Column(name = "discount_percentage", nullable = false)
	private BigDecimal discountPercentage;

}
