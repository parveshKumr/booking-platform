package com.booking.platform.service;

import java.util.List;

import com.booking.platform.entity.ShowTime;
import com.booking.platform.model.ShowTimeModel;

public interface ShowTimeService {

	List<ShowTime> createUpdateShowTime(final List<ShowTimeModel> model);
	void deleteShowTime(final Long id);
}
