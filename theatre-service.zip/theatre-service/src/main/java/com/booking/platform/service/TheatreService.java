package com.booking.platform.service;

import java.util.List;

import com.booking.platform.entity.Theatre;

public interface TheatreService {

	List<Theatre> getTheatersBasedOnMovieCityAndDate(Long movieId, String city, String showDate);
	Theatre findTheatreById(final Long theatreId);
}
